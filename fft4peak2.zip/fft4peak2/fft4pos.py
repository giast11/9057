#!/usr/bin/python3
import matplotlib
matplotlib.use('TkAgg')
from matplotlib import pyplot as plt
from matplotlib import animation
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.widgets import Slider,SpanSelector
import numpy as np
import numpy 
import random
import time
import spidev
import time
import time
import threading
import sys
import os
import math
import RPi.GPIO as GPIO

#from mttkinter import mtTkinter as tk
import tkinter as tk
import mttkinter   ## separate thread 에서 tk main ui 조작 가능하게 하는 모듈

#from functools import partial

#####  IMPORT Fake Input/Output Data #####

from fakedata import fake_input,fake_output_even,fake_output_odd



###### SPI slave device 0 for ADC mcp3208 with analog mic ######

spi_adc  = None

def spi_adc_open():
        global spi_adc
        spi_adc = spidev.SpiDev() ## adc spi dev
        spi_adc.open(0,0)  ## first slave spi device
        #spi_adc.max_speed_hz = 1000000 ## half of max spi clock for mcp3208, 1MHz, stable
        #spi_adc.max_speed_hz = 2000000 ## macp3208 's max spi clock is 2MHz, but maybe unstable 
        spi_adc.max_speed_hz = global_spi_speed_adc

        relay1_off()  ## disconnect FPGA Dout to Rpi MISO
        relay2_off()  ## disconnect FPGA Dout to Rpi MISO

def spi_adc_close():
        global spi_adc

        relay1_on()   ## connect FPGA Dout to Rpi MISO
        relay2_on()   ## connect FPGA Dout to Rpi MISO

        if spi_adc!=None:
           spi_adc.close()
           spi_adc= None



###### read real analog mic pulse data from mcp3208 adc #####
######  return 3 float numbers: 10bit amplitude, high 2bits, lower 8bits
######   mcp3208 has 8 adc channels ( 0 ~ 7), 10 bits ( 0 ~ 1024 range)

def adc_read_real(channel):
      try:
         r = spi_adc.xfer2([1, (0x08+channel)<<4, 0])
      except:
         r = [0,0,0,0, 0,0,0,0]
      adc_out_high8= r[1] & 0x03  ## high 2 bits
      adc_out_low8=  r[2]         ## lower 8 bits
      adc_out16 = (adc_out_high8<<8) + adc_out_low8
      return adc_out16,adc_out_high8,adc_out_low8

ax=0

###### read fake analog data #####
######  return 3 float numbers: 10bit amplitude, high 2bits, lower 8bits

def adc_read_fake(channel):
      global ax
      time.sleep(0.00000001)
      r= fake_input[ax] ## defined in and imported from ./fakedata.py
      ax=ax+1
      ax=ax%256
      adc_out_high8= r[0] & 0x03   ## high 2 bits
      adc_out_low8=  r[1]          ## low 8 bits
      adc_out16 = (adc_out_high8<<8) + adc_out_low8
      return adc_out16,adc_out_high8,adc_out_low8



#####
#####  setup for GPIO pins to control FPGA  #####
#####

finish_sign = 26   # GPIO.IN pin number for finish sign from FPGA: fft job finished
start_sign = 17    # GPIO.OUT pin number for start sign
valid_256data_in = 23      # GPIO.OUT pin number to indicate valid 256data has been transferred
reset_sign = 24    # GPIO.OUT pin number for reset internal FPGA data to zeros

relay_in1= 21  ## relay no 1
relay_in2= 18  ## relay no 2

#relay_in1= 18  ## relay no 1
#relay_in2= 21  ## relay no 2

### setup 4 GPIO pins , called from main() 
def rpi_gpio_setup():
        GPIO.setmode(GPIO.BCM) #GPIO mode setting
        GPIO.setwarnings(False) #I don't know about this but it is necessary

        GPIO.setup(valid_256data_in,GPIO.OUT)
        GPIO.setup(start_sign,GPIO.OUT) 
        GPIO.setup(reset_sign,GPIO.OUT)
        GPIO.setup(finish_sign,GPIO.IN)

	### relay module control gpio pins to cut off FPGA Dout
        GPIO.setup(relay_in1,GPIO.OUT) 
        GPIO.setup(relay_in2,GPIO.OUT)
        time.sleep(1)
        GPIO.output(relay_in1,False) ## 릴레이 모듈의 적색 LED 가 켜진다 (off 상태임을 의미)
        GPIO.output(relay_in2,False) 


def relay1_on():
        GPIO.output(relay_in1, True)
        time.sleep(0.1) ## wait 0.1sec until relay mechanical switching action finished
        # 이때 렐레이 모듈의 적생LED가 꺼진다, relay1 상태와 LED 켜짐은 서로 반대이다
        # fpga Dout 연결을 재개한다 
 
def relay1_off():
        GPIO.output(relay_in1, False)
        time.sleep(0.1) ## wait 0.1sec until relay mechanical switching action finished
        # 이때 렐레이 모듈의 적생LED가 켜진다, relay1 상태와 LED 켜짐은 서로 반대이다
        # fpga Dout 연결을 끊는다
 
def relay2_on():
        GPIO.output(relay_in2, True)
        time.sleep(0.1) ## wait 0.1sec until relay mechanical switching action finished
 
def relay2_off():
        GPIO.output(relay_in2, False)
        time.sleep(0.1) ## wait 0.1sec until relay mechanical switching action finished
 
###### SPI slave device 1 for for FPGA ######

spi_fpga = None

def spi_fpga_open():
        global spi_fpga
        spi_fpga = spidev.SpiDev() ## fpga spi device
        spi_fpga.open(0,1)   ## second spi slave device
        #spi_fpga.max_speed_hz =12500000 # HALF FAST: half of max SPI clock for zynq 70x0, stable
        #spi_fpga.max_speed_hz = 25000000 # MOST FAST: zynq 70x0 max spi clock is 25MHz, maybe unstable
        #spi_fpga.max_speed_hz = 100000 # VERY SLOW: 
        spi_fpga.max_speed_hz = global_spi_speed_fpga # VERY SLOW: 

        relay1_on()   ## connect FPGA Dout to Rpi MISO
        relay2_on()   ## connect FPGA Dout to Rpi MISO

def spi_fpga_close():
        global spi_fpga

        relay1_off()  ## disconnect FPGA Dout to Rpi MISO
        relay2_off()  ## disconnect FPGA Dout to Rpi MISO

        if spi_fpga!=None:
           spi_fpga.close()
           spi_fpga= None


def spi_input_data_write_begin():
    GPIO.output(reset_sign,True)
    GPIO.output(reset_sign,False)
    GPIO.output(reset_sign,True)
    GPIO.output(valid_256data_in,False)


def spi_input_data_write_end():
    GPIO.output(start_sign,True)
    GPIO.output(valid_256data_in,True)
    GPIO.output(start_sign,False)


def spi_output_data_read_end():
    GPIO.output(valid_256data_in,False)
    GPIO.output(start_sign,True)
    GPIO.output(start_sign,False)


def spi_wait_until_fft_output_data_ready():
    count=0
    while True and count<100:
        flag=GPIO.input(finish_sign)
        count= count+1
        if flag == 1:
          break
        time.sleep(0.001)


#### send [block_no] input 256block data into FPGA and get FFT response
####    parameters: block_no: adc input 256block index

def spi_data_sent_a_block(block_no):
    global fpga_input
    global fpga_output_raw

    ## gpio signals for starting to send a block
    spi_input_data_write_begin()

    ### send 256 input data to fpga ###
    adc_data_arr= fpga_input[block_no]
    for i in range(block_size):
        try:
          spi_fpga.xfer2([0x80,0x00,0x00,i, 0x00,0x00,int(adc_data_arr[i][0]),int(adc_data_arr[i][1])])
        except:
          pass

    ## gpio signals for finishing to send a block
    spi_input_data_write_end()

    ## wait until fpga calculate fft results
    spi_wait_until_fft_output_data_ready()

    ### start reading output fft response ###
    res_addr1 = 0
    res_addr2 = 2

    #for i in range(263):
    #for i in range(block_size_fft_result):
    for i in range(block_size): ## ignore additional 7 results
        try:
          re = spi_fpga.xfer2([0x00,0x00,res_addr2,res_addr1, 0x00,0x00,0x00,0x00])
        except:
          re = [0,0,0,0, 0,0,0,0]

        #print(re)
        # re: size 8 int array
        fpga_output_raw[block_no][i] = np.array(re, dtype=int)
        if res_addr1 == 255:
          res_addr1 = 0
          res_addr2 = res_addr2 + 1
        else:
          res_addr1 = res_addr1 + 1

    ### gpio signals for finishing to read fft response
    spi_output_data_read_end()

    return fpga_output_raw[block_no]



### convert little endian short signed integer (16bit intege) ###
###    convert 255 255 pair => 65535 => -1
###    convert 128 0   pair => 32768 => -32768
###    neg int ==> 2's complement form  ( 32768 ~ 65535, 0x8000 ~ 0xffff)

def signed_int16(x):
    if x >=  32768:
       return  x - 65536
    return x




######  Global VARIABLES for ADC/FPGA EVENT HANDLER ######

## count how many adc analog input we got
ib_count=0

## how many 256 input blocks : ib_count/block_size
ib_count_block=0

## count how many input blocks we sent to fpga
send_block_count=0



## ADC 데이터 캡춰 시작 시간 
capture_start_time = 0

## ADC 데이터 캡춰 종료 시간
capture_stop_time = 0

## ADC 캡춰 시간 (sec)
capture_duration = 0

## 실제 측정된 샘플링 레이트:estimated sampling rate
sampling_rate= 0

freq_xrange=None


###### FAKE DATA ADC/FPGA EVENT HANDLER ######


### fake input data 로부터 input data 배열(fpga_input)을 채우고 상단 그래프를 갱신한다

def adc_fake():
    global line_data1 ## 상단 그래프 y 값 배열
    global sample_signal_min
    global sample_signal_max
    global fpga_input
    global countbox
    global timebox
    global speedbox
    global capture_start_time
    global capture_stop_time
    global capture_duration
    global global_capture_started
    global global_capture_finished
    global global_fft_batch_started
    global global_fft_batch_finished
    global ib_count
    global ib_count_block
    global sampling_rate

    ib_max= num_view_samples
    ib_count  = 0
    ib_count_block  = 0
    capture_start_time= time.time()
    ib=[]
    adc_channel=0

    while ib_count<ib_max and global_capture_started==True:
        y,high,low = adc_read_fake(adc_channel)
        ib.append([y,high,low])
        ib_count += 1
        if ib_count%block_size==0:
            now_time= time.time()
            capture_stop_time= now_time
            ib_count_block = ib_count_block + 1
            elapsed_time= now_time - capture_start_time
            #countbox.set("fake samples#: "+str(ib_count))
            #timebox.set("Duration: "+str(int(elapsed_time))+" secs")
            #speedbox.set("Speed: "+str(int(ib_count/elapsed_time))+" sps")
            #최대 캡춰 시간을 초과했거나, 버퍼까 찼거나, 캡춰 중단 단추를 누르면 루프를 빠져 나간다
            if ib_count==ib_max or global_capture_started==False or elapsed_time> max_capture_duration_sec:
               break

    ## 하단 상태 정보란을 갱신한다
    sampling_rate= int(ib_count/elapsed_time)+1
    capture_duration= elapsed_time
    if True:
            elapsed_time= now_time - capture_start_time
            countbox.set("fake samples#: "+str(ib_count) + ",  256block# "+str(int(ib_count_block)) )
            timebox.set("Duration: %.4f secs" % (capture_duration)) 
            speedbox.set("Speed: "+str(sampling_rate)+" sps")

    i=0
    ibn=0
    while i < ib_count:
        aa=ib[i]
        ## 상단 그래프 실선 y 값으로 복사
        line_data1[i]= aa[0]
        fpga_input[ibn][i%block_size]= np.array([aa[1],aa[2]], dtype=int)
        i = i+1
        if i%block_size==0:
           ibn=ibn+1
    ## 미캡춰된 데이타 영역은 그래프 실선으로 표시되지 않도록 NAN 처리
    while i < ib_max:
        line_data1[i]= np.nan
        i = i+1

    ## 상단 사운드 소스 자료 그래프를 갱신
    ax1.clear()
    #ax1.axis([0,one_view_samples,0,signal_max1])
    sample_signal_min= max( np.nanmin(line_data1) - 10, 0)
    sample_signal_max= min( np.nanmax(line_data1) + 10, signal_max1)

    ax1.axis([0,one_view_samples, sample_signal_min, sample_signal_max])
    ax1.plot(np.arange(num_view_samples),line_data1,lw=1, c=ax1_color,ms=1)
    plt.draw()
    ax1.set_title('Raw PCM Source: captured samples#'+str(ib_count) + " block#: "+str(ib_count_block))
    global_capture_started= False
    global_capture_finished= True

    ## 데이타 취득이 끝나면 자동으로 FFT 배치 처리를 시작        
    global_fft_batch_started=True
    fft_fake_batch()
    global_fft_batch_started=False
    global_fft_batch_finished=True


### FAKE OUTPUT DATA 로부터 FFT 결과를 받아 배열에 저장한다

def fft_fake_batch():
    global line2
    global line_data2
    global send_block_count
    global fftbox
    global freq_xrange
    global fmax_neg
    global fmax_pos

    send_block_count  = 0
    avg_block_amp= np.zeros(block_size)

    while send_block_count < ib_count_block:
        if send_block_count%2==0:
           fake_out= fake_output_even
        else:
           fake_out= fake_output_odd
        fftbox.set("FFT block# "+str(send_block_count))
        xbstart= send_block_count*block_size
        xbend = xbstart + block_size
        if debug_log==True:
           print("FFT "+str(send_block_count) + " , "+str(xbstart)+":"+str(xbend))

        fpga_output_raw[send_block_count]= fake_out

        a256= np.zeros(block_size) 

        for i  in range(half_block_size): #pos half_block_size
          a= fake_out[i]
          ampr= (a[4] << 8) + (a[5])
          ampr= signed_int16(ampr) 
          ampi= (a[6] << 8) + (a[7])
          ampi= signed_int16(ampi) 
          amp = math.sqrt(ampr*ampr + ampi*ampi)
          a256[i+1+half_block_size - 1]= amp  ## index: 1 ~ 127
        for i  in range(half_block_size): #neg half_block_size
          a= fake_out[i+half_block_size]
          ampr = (a[4] << 8) + (a[5])
          ampr = signed_int16(ampr) #* ( send_block_count % 2 + 1)
          ampi= (a[6] << 8) + (a[7])
          ampi= signed_int16(ampi) #* ( send_block_count % 2 + 1)
          amp = math.sqrt(ampr*ampr + ampi*ampi)
          #a256[i]= -amp  ## index: 0 ~ 127- 1, 127 => zero freq
          a256[-i + half_block_size - 1]= -amp  ## index: 0 ~ 127- 1, 127 => zero freq

        ## zero center peak: freq 0 위치의 그래프 피크를 교정
        #a256[half_block_size-1]=0
        #a256[half_block_size+1]=0
        a256[half_block_size  ]=0  ## remove 0 peak

        fpga_output_amp[send_block_count]= a256

        avg_block_amp = avg_block_amp + a256
        send_block_count = send_block_count + 1
   
    fftbox.set("FFT block# "+str(int(send_block_count-1))+" *** ")
    # fft 합산 평균 값을 구한다 
    avg_block_amp = avg_block_amp / send_block_count

    ## 하단 그래프를 갱신한다
    freq_unit= int(sampling_rate/block_size)
    fmax_pos=  freq_unit* block_size 
    fmax_neg=  freq_unit* block_size * -1

    if global_graph_style=='Line':
      freq_xrange= np.linspace(fmax_neg, fmax_pos, block_size)
      line2, = ax2.plot(freq_xrange, avg_block_amp, lw=1, c=ax2_bar_color,ms=1)
      line_data2 = line2.get_ydata()
      ax2.set_xlim([fmax_neg,fmax_pos])

    if global_graph_style=='Pulse':
      freq_xrange= np.linspace(0, fmax_pos, half_block_size)
      ax2.bar(freq_xrange, avg_block_amp[half_block_size:], alpha=1, width=ax2_bar_width, linewidth=ax2_bar_linewidth, align='center', color=ax2_bar_color, edgecolor=ax2_bar_color, facecolor=ax2_bar_color)
      #ax2.axhspan(-1,1,xmin=fmax_neg,xmax=fmax_pos,color='gray',alpha=0.3)
      #ax2.axvspan(-1,1,ymin=-signal_max2*0.8,ymax=signal_max2*0.8,color='gray',alpha=0.3)
      line_data2 = avg_block_amp
      ax2.set_xlim([0,fmax_pos])

    k_sampling_rate=int(sampling_rate/100)/10.0
    ax2.set_xlabel('Frequency (-%.1f KHz ~ %.1f KHz)'%(0,k_sampling_rate))
    ax2.set_title('Frequency Distribution Average from FFT for all '+str(ib_count)+' samples',pad=-90)
    plt.draw()



##### REAL ADC/FPGA HANDLER ######

def adc_real():
    global line_data1 ## 상단 그래프 y 값 배열
    global sample_signal_min
    global sample_signal_max
    global fpga_input
    global countbox
    global timebox
    global speedbox
    global capture_start_time
    global capture_stop_time
    global capture_duration
    global global_capture_started
    global global_capture_finished
    global global_fft_batch_started
    global global_fft_batch_finished
    global ib_count
    global ib_count_block
    global sampling_rate

    ib_max= num_view_samples
    ib_count  = 0
    ib_count_block  = 0
    capture_start_time= time.time()
    ib=[]
    adc_channel=0

    ## ADC SPI device 를 연다
    spi_adc_open()

    while ib_count<ib_max and global_capture_started==True:
        y,high,low = adc_read_real(adc_channel)
        ib.append([y,high,low])
        ib_count += 1
        if ib_count%block_size==0:
            now_time= time.time()
            capture_stop_time= now_time
            ib_count_block = ib_count_block + 1
            elapsed_time= now_time - capture_start_time
            #countbox.set("real samples#: "+str(ib_count))
            #timebox.set("Duration: "+str(int(elapsed_time))+" secs")
            #speedbox.set("Speed: "+str(int(ib_count/elapsed_time))+" sps")
            #최대 캡춰 시간을 초과했거나, 버퍼까 찼거나, 캡춰 중단 단추를 누르면 루프를 빠져 나간다
            if ib_count==ib_max or global_capture_started==False or elapsed_time> max_capture_duration_sec:
               break

    ## 하단 상태 정보란을 갱신한다
    sampling_rate= int(ib_count/elapsed_time)+1
    capture_duration= elapsed_time
    if True:
            elapsed_time= now_time - capture_start_time
            countbox.set("real samples#: "+str(ib_count) + ",  256block# "+str(int(ib_count_block)) )
            timebox.set("Duration: %.4f secs" % (capture_duration)) 
            speedbox.set("Speed: "+str(sampling_rate)+" sps")

    ## ADC SPI device 를 닫는다
    spi_adc_close()

    i=0
    ibn=0
    while i < ib_count:
        aa=ib[i]
        ## 상단 그래프 실선 y 값으로 복사
        line_data1[i]= aa[0]
        fpga_input[ibn][i%block_size]= np.array([aa[1],aa[2]], dtype=int)
        i = i+1
        if i%block_size==0:
           ibn=ibn+1
    ## 미캡춰된 데이타 영역은 그래프 실선으로 표시되지 않도록 NAN 처리
    while i < ib_max:
        line_data1[i]= np.nan
        i = i+1

    ## 상단 사운드 소스 자료 그래프를 갱신
    ax1.clear()
    #ax1.axis([0,one_view_samples,0,signal_max1])
    sample_signal_min= max( np.nanmin(line_data1) - 10, 0)
    sample_signal_max= min( np.nanmax(line_data1) + 10, signal_max1)

    ax1.axis([0,one_view_samples, sample_signal_min, sample_signal_max])
    ax1.plot(np.arange(num_view_samples),line_data1,lw=1, c=ax1_color,ms=1)
    plt.draw()
    ax1.set_title('Raw PCM Source: captured samples#'+str(ib_count) + " block#: "+str(ib_count_block))
    global_capture_started= False
    global_capture_finished= True
            
    ## 데이타 취득이 끝나면 자동으로 FFT 배치 처리를 시작        
    global_fft_batch_started=True
    fft_real_batch()
    global_fft_batch_started=False
    global_fft_batch_finished=True




### FPGA 로 256 블럭들을 하나씩 보내서 FFT 결과를 받아 배열에 저장한다

def fft_real_batch():
    global line2
    global line_data2
    global send_block_count
    global fftbox
    global freq_xrange
    global fmax_neg
    global fmax_pos

    send_block_count  = 0
    avg_block_amp= np.zeros(block_size)

    ## fpga spi device 를 연다
    spi_fpga_open()

    while send_block_count < ib_count_block:
        fftbox.set("FFT block# "+str(send_block_count))
        xbstart= send_block_count*block_size
        xbend = xbstart + block_size
        if debug_log==True:
           print("FFT "+str(send_block_count) + " , "+str(xbstart)+":"+str(xbend))

        ### 한 블록의 데이타를 실제 FPGA 로 보낸다 
        real_out= spi_data_sent_a_block(send_block_count)

        #fpga_output_raw[send_block_count]= real_out
        a256= np.zeros(block_size)
 
        for i  in range(half_block_size): #pos half_block_size
          a= real_out[i]
          #print(a)
          ampr= (a[4] << 8) + (a[5])
          ampr= signed_int16(ampr) 
          ampi= (a[6] << 8) + (a[7])
          ampi= signed_int16(ampi) 
          amp = math.sqrt(ampr*ampr + ampi*ampi)
          a256[i+1+half_block_size - 1]= amp  ## index: 1 ~ 127
        for i  in range(half_block_size): #neg half_block_size
          a= real_out[i+half_block_size]
          ampr = (a[4] << 8) + (a[5])
          ampr = signed_int16(ampr) #* ( send_block_count % 2 + 1)
          ampi= (a[6] << 8) + (a[7])
          ampi= signed_int16(ampi) #* ( send_block_count % 2 + 1)
          amp = math.sqrt(ampr*ampr + ampi*ampi)
          #a256[i]= -amp  ## index: 0 ~ 127- 1, 127 => zero freq
          a256[-i + half_block_size - 1]= -amp  ## index: 0 ~ 127- 1, 127 => zero freq

        ## zero center peak: freq 0 위치의 그래프 피크를 교정
        #a256[half_block_size-1]=0
        #a256[half_block_size+1]=0
        a256[half_block_size  ]=0  ## remove 0 peak

        fpga_output_amp[send_block_count]= a256

        avg_block_amp = avg_block_amp + a256

        send_block_count = send_block_count + 1

    
    ## fpga spi device 를 닫는다
    spi_fpga_close()

    fftbox.set("FFT block# "+str(int(send_block_count-1))+" *** ")
    # fft 합산 평균 값을 구한다 
    avg_block_amp = avg_block_amp / send_block_count


    ## 하단 그래프를 갱신한다
    freq_unit= int(sampling_rate/block_size)
    fmax_pos=  freq_unit* block_size 
    fmax_neg=  freq_unit* block_size * -1

    if global_graph_style=='Line':
      freq_xrange= np.linspace(fmax_neg, fmax_pos, block_size)
      line2, = ax2.plot(freq_xrange, avg_block_amp, lw=1, c=ax2_bar_color,ms=1)
      line_data2 = line2.get_ydata()
      ax2.set_xlim([fmax_neg,fmax_pos])

    if global_graph_style=='Pulse':
      freq_xrange= np.linspace(0, fmax_pos, half_block_size)
      ax2.bar(freq_xrange, avg_block_amp[half_block_size:], alpha=1, width=ax2_bar_width, linewidth=ax2_bar_linewidth, align='center', color=ax2_bar_color, edgecolor=ax2_bar_color, facecolor=ax2_bar_color)
      #ax2.axhspan(-1,1,xmin=fmax_neg,xmax=fmax_pos,color='gray',alpha=0.3)
      #ax2.axvspan(-1,1,ymin=-signal_max2*0.8,ymax=signal_max2*0.8,color='gray',alpha=0.3)
      line_data2 = avg_block_amp
      ax2.set_xlim([0,fmax_pos])

    k_sampling_rate=int(sampling_rate/100)/10.0
    ax2.set_xlabel('Frequency (%.1f KHz ~ %.1f KHz)'%(0,k_sampling_rate))
    ax2.set_title('Frequency Distribution Average from FFT for all '+str(ib_count)+' samples',pad=-90)
    plt.draw()



### 각 256 블럭 마다의 개별 fft 결과를 fpga_output 배열에서 찾아 하단 그래프를 갱신한다
###   update_ax1_manual()
###   update_ax1_onclick() 두개의 함수로부터 호출된다

def fft_replay_blockwise(bn):
    global line_data2 ## 하단 그래프 y 값 배열 
    global send_block_count
    global replayfftbox
    global freq_xrange
    global fmax_neg
    global fmax_pos

    if bn < ib_count_block:
        if bn < ib_count_block-1:
          replayfftbox.set("FFT replay# "+str(bn))
        else:
          replayfftbox.set("FFT replay# "+str(bn)+ " ***")
        line_data2 = fpga_output_amp[bn]

        if global_graph_style=='Line':
          line2.set_ydata(line_data2)
    
        if global_graph_style=='Pulse':
          ax2.clear()
          ax2.bar(freq_xrange, line_data2[half_block_size:], alpha=1, width=ax2_bar_width, linewidth=ax2_bar_linewidth, align='center', color=ax2_bar_color, edgecolor=ax2_bar_color, facecolor=ax2_bar_color)
          #ax2.axhspan(-1,1,xmin=fmax_neg,xmax=fmax_pos,color='gray',alpha=0.3)
          #ax2.axvspan(-1,1,ymin=-signal_max2*0.8,ymax=signal_max2*0.8,color='gray',alpha=0.3)

        if bn==0:
           ax2.set_title('Frequency Distribution from FFT for highlighted '+str(block_size)+' samples block above',pad=-90)
        xbstart= bn*block_size
        xbend = xbstart + block_size
        if debug_log==True:
           print("fft replay block# "+str(bn) + " , "+str(xbstart)+":"+str(xbend))




########################## graph plot event handler ###############################

global_mode= None  # "fake","real"
global_capture_started= False
global_capture_finished= False
global_fft_batch_started= False
global_fft_batch_finished= False
global_fft_replay_block= 0
global_fft_replay_started= False
global_fft_replay_finished= False


def capture_start_real():
   global global_capture_started
   global global_capture_finished
   global global_fft_batch_started
   global global_fft_batch_finished
   global global_fft_replay_started
   global global_fft_replay_finished
   global ib_count
   global ib_count_block
   global global_mode
   global line_data1
   global line_data2

   if global_fft_batch_started== True:
      return
   if global_fft_replay_started== True:
      return
   if global_capture_started== True:
      return
   
   global_capture_finished= False
   global_fft_batch_started= False
   global_fft_batch_finished= False
   global_fft_replay_started= False
   global_fft_replay_finished= False
   if debug_log==True:
      print("real capture start")

   fftbox.set("")
   replayfftbox.set("")
   timebox.set("")
   speedbox.set("")
   countbox.set("Capturing Sounds ... max %d secs" % (max_capture_duration_sec))

   global_mode= "real"
   global_capture_started= True
   ib_count=0
   ib_count_block=0

   line_data1= np.array(init_line_data1, dtype=float)
   line_data2= np.array(init_line_data2, dtype=float)
   th1 = threading.Thread(target = adc_real)
   th1.daemon = True
   th1.start()
   # adc_real set global_capture_finished= True when exit
   # th1 thread exits when max capture duration is reached or stop capture button is pressed



def capture_start_fake():
   global global_capture_started
   global global_capture_finished
   global global_fft_batch_started
   global global_fft_batch_finished
   global global_fft_replay_started
   global global_fft_replay_finished
   global ib_count
   global ib_count_block
   global global_mode
   global line_data1
   global line_data2

   if global_fft_batch_started== True:
      return
   if global_fft_replay_started== True:
      return
   if global_capture_started== True:
      return
   
   global_capture_finished= False
   global_fft_batch_started= False
   global_fft_batch_finished= False
   global_fft_replay_started= False
   global_fft_replay_finished= False
   if debug_log==True:
      print("fake capture start")

   fftbox.set("")
   replayfftbox.set("")
   timebox.set("")
   speedbox.set("")
   countbox.set("Capturing Sounds ... max %d secs" % (max_capture_duration_sec))

   global_mode= "fake"
   global_capture_started= True
   ib_count=0
   ib_count_block=0

   line_data1= np.array(init_line_data1, dtype=float)
   line_data2= np.array(init_line_data2, dtype=float)
   th1 = threading.Thread(target = adc_fake)
   th1.daemon = True
   th1.start()
   # adc_fake set global_capture_finished= True when exit
   # th1 thread exits when max capture duration is reached or stop capture button is pressed


def capture_stop():
   global global_capture_started
   global global_mode
   global countbox
   if global_capture_started==True:
      global_capture_started= False   ## this will make th1 thread exit the loop


def fft_process():
   global global_captue_started
   global global_fft_batch_started
   global global_fft_batch_finished
   global global_mode
   global fftbox
   if global_capture_finished==False:
      return
   if global_fft_batch_started==False:
      global_fft_batch_started= True
      fftbox.set("FFT running: ")
      if global_mode=="fake":
         fft_fake_batch()
         pass
      if global_mode=="real":
         fft_real_batch()
         pass
      global_fft_batch_finished= True
      global_fft_batch_started= False


def fft_replay():
   global global_captue_started
   global global_captue_finished
   global global_fft_batch_started
   global global_fft_batch_finished
   global global_fft_replay_started
   global global_fft_replay_block
   global replayfftbox
   if global_capture_finished==False:
      return
   if global_fft_batch_finished==False:
      return
   if global_fft_replay_started==False:
      global_fft_replay_started= True
      global_fft_replay_block=0
      replayfftbox.set("FFT replaying: ")
      #tk_clock set global_fft_replay_finished= True when replay loop exit


### matplotlib.FuncAnimation() 함수 대신, 그래프 애니메이션을 구현하는 타이머 함수이다
###  matplotlib.FuncAnimation() 는 cpu time 을 너무 많이 소뫃하여 adc 고속 자료 취득을 방해한다
###  0.1 초 (100 미리세컨드) 마다 한번씪 호출되어, 그래프 갱신할 업무가 있으면 처리한다
###  called from main()

def tk_clock():
    global global_fft_replay_started
    global global_fft_replay_block
    if global_fft_batch_finished==True: ## fft 처리가 끝난 후에만 replay 가능하다
            if global_fft_replay_started==True:
               sam_pos=global_fft_replay_block*block_size
               ### 한 블럭의 데이타를 위해 상단/하단  그래프를 모두를 갱신한다
               update_ax1_manual(sam_pos)
               ### 최상단 slider 값을 block 시작점에 맞추어 갱신한다
               spos.set_val(sam_pos)
               ### 마지막 블록까지 animation 했으면 종료한다
               if (global_fft_replay_block+1)*block_size == ib_count:
                   global_fft_replay_started = False
                   global_fft_replay_finished = True
                   global_fft_replay_block = 0
               else:
                   global_fft_replay_block= global_fft_replay_block+1
            else:
               global_fft_replay_block=0
    ## 100 미리세컨드마다 실행한다
    root.after(100,tk_clock)


### 앱을 종료한다, Exit 버튼 눌렀을 때 작동한다

def exit1():
    exit(0)



#### GRAPH ANIMATION HANDLER ####

last_vspan=None
last_vbar=None
last_spos_256= None

## 상단 slider 를 클릭했을 때 작동한다
##  클릭된 위치의 입력 데이터 순번과 그에 해당하는 블록을 찾아
###   상단/하단 그래프를 모두 갱신하는 이벤트 핸들러다

def update_ax1_onclick(val):
    global last_vspan
    global last_vbar
    global last_spos_256
    if global_fft_replay_started==True:
       return
    ### slider 의 클릭된 위치값을 얻는다
    pos = spos.val
    ### 선택된 데이터 항목이 소속된 256블럭의 시작점을 찾는다
    last_spos_256= int(pos)
    posr= pos % block_size
    if posr>0:
       last_spos_256 = int(pos - posr)

    strt= pos - one_view_samples_half
    end1= pos + one_view_samples_half
    if end1 > num_view_samples:
       end1 = num_view_samples
       strt = end1 - one_view_samples
    if strt<0:
       strt=0
       end1= one_view_samples
    ## 상단 그래프의 x 축을 이동시킨다
    ax1.axis([strt,end1,sample_signal_min,sample_signal_max])

    ## 하이라이트된 그래프 음영이 있다면 제거한다
    if last_vspan != None:
       last_vspan.remove()
    if last_vbar != None:
       last_vbar.remove()
    ## 선택된 상단 그래프 블록 영역(256 넓이)를 녹색 음영으로 강조처리한다
    last_vspan= ax1.axvspan(last_spos_256,last_spos_256+ block_size,alpha=0.4,color='green')
    last_vbar= ax1.axvspan(pos,pos+10,alpha=0.8,color='green')

    ttl=  str(last_spos_256) + " ~ " + str(int(last_spos_256+ block_size-1)) 
    bn=  int(last_spos_256/ block_size)
    ttl2=  '  block# ' + str(bn)
    block_start_time=  (last_spos_256) * capture_duration / ib_count
    block_end_time=  (last_spos_256+block_size) * capture_duration / ib_count
    ttl3=  '  timespan: %.4f ~ %.4f sec' % (block_start_time,block_end_time)
    ax1.set_title('Raw PCM Source : highlighted '+str(block_size)+' samples '+ttl+ ttl2 + ttl3)

    ## 하단 FFT 그래프를 갱신한다
    fft_replay_blockwise(bn)



## 하단부 replay fft 버튼을 눌렀을 때, 배 블록을 보여줄 때마다 호출된다
##   해당 블록과 ADC 데이터을 위한 상단/하단 그래프를 모두 갱신하는 이벤트 핸들러다
##   pos: 입력 데이터의 순번이다

def update_ax1_manual(pos):
    global last_vspan
    global last_vbar
    global last_spos_256
    
    ### 선택된 데이터 항목이 소속된 256블럭의 시작점을 찾는다
    last_spos_256= int(pos)
    posr= pos % block_size
    if posr>0:
       last_spos_256 = int(pos - posr)
    strt= pos - one_view_samples_half
    end1= pos + one_view_samples_half
    if end1 > num_view_samples:
       end1 = num_view_samples
       strt = end1 - one_view_samples
    if strt<0:
       strt=0
       end1= one_view_samples
    ## 상단 그래프의 x 축을 이동시킨다
    ax1.axis([strt,end1,sample_signal_min,sample_signal_max])

    ## 하이라이트된 그래프 음영이 있다면 제거한다
    if last_vspan != None:
       last_vspan.remove()
    if last_vbar != None:
       last_vbar.remove()

    ## 선택된 상단 그래프 블록 영역(256 넓이)를 녹색 음영으로 강조처리한다
    last_vspan= ax1.axvspan(last_spos_256,last_spos_256 + block_size,alpha=0.4,color='green')
    last_vbar= ax1.axvspan(pos,pos+10,alpha=0.8,color='green')

    ttl=  str(last_spos_256) + " ~ " + str(int(last_spos_256+ block_size -1)) 
    bn=  int(last_spos_256/ block_size)
    ttl2=  '  block# ' + str(bn)
    block_start_time=  (last_spos_256) * capture_duration / ib_count
    block_end_time=  (last_spos_256+block_size) * capture_duration / ib_count
    ttl3=  '  timespan: %.4f ~ %.4f sec' % (block_start_time,block_end_time)
    ax1.set_title('Raw PCM Source : highlighted '+str(block_size)+' samples '+ttl+ ttl2 + ttl3)

    ## 하단 FFT 그래프를 갱신한다
    fft_replay_blockwise(bn)



##########################  GRAPH OBJECT SETUP  ###########################
 
root = tk.Tk()

#root.geometry('+%d+%d'%(0,0))  ## position window at left-top (0,0)
root.geometry('1920x1100+%d+%d'%(0,0))  ## position window at left-top (0,0)

window_title="PCM2FFT - 우리연구실"
root.title(window_title)

# 13.3 inch wide, 6.6 inch height on monitor with 96 dpi
#fig = plt.figure(figsize=(13.3,6.6), dpi=96)
#fig = plt.figure(figsize=(13.3,7.6), dpi=96)
#fig = plt.figure(figsize=(20,9.5), dpi=96)
fig = plt.figure(figsize=(20,9.5), dpi=72)

canvas = FigureCanvasTkAgg(fig, master=root)
plot_widget = canvas.get_tk_widget()

#### Position 3 WINDOW ROOT WIDGETS in 3 layers ####
plot_widget.grid(row=0, column=0, columnspan=1)  
option_line= tk.Frame(root)
option_line.grid(row=1, column=0, columnspan=1)  
status_line= tk.Frame(root)
status_line.grid(row=2, column=0, columnspan=1)  
button_line= tk.Frame(root)
button_line.grid(row=3, column=0, columnspan=1)  


#### OPTION AREA ####

line_pulse_graph_var = tk.StringVar()
line_pulse_graph_choices= { "Pulse", "Line" }
#line_pulse_graph_var.set("Line")
#global_graph_style="Line"
line_pulse_graph_var.set("Pulse")
global_graph_style="Pulse"

def update_line_pulse_graph(ev):
    global global_graph_style
    global_graph_style = line_pulse_graph_var.get()
    print("new graph mode: "+global_graph_style)

line_pulse_graph_label = tk.Label(option_line, text="Select Graph Style: ", font="Arial 10", anchor='w')
line_pulse_graph_label.pack(side="left",fill="x")

line_pulse_graph = tk.OptionMenu(option_line, line_pulse_graph_var, *line_pulse_graph_choices,
	command= update_line_pulse_graph)
line_pulse_graph.config(width=10, font=('Helvetica', 10))
line_pulse_graph.pack(side="left", fill="x")


#  cdiv    speed
#     2    125.0 MHz
#     4     62.5 MHz
#     8     31.2 MHz
#    16     15.6 MHz
#    32      7.8 MHz
#    64      3.9 MHz
#   128     1953 kHz
#   256      976 kHz
#   512      488 kHz
#  1024      244 kHz
#  2048      122 kHz
#  4096       61 kHz
#  8192     30.5 kHz
# 16384     15.2 kHz
# 32768     7629 Hz

adc_spi_speed_var = tk.StringVar()
adc_spi_speed_choices = [ 
	'2000000/2MHz/24,000sps',
	'1000000/1MHz/17,800sps',
	'500000/500KHz/7,100sps',
	'250000/250KHz/3,600sps',
	'125000/125KHz/2,100sps',
	'62500/62.5KHz/1,200sps',
	'31300/31.3KHz/650sps',
	'15200/15.2KHz/330sps' 
]

adc_spi_speed_var.set('2000000/2MHz/24,000sps') # set the default option
global_spi_speed_adc= 2000000 # 2MHz max for mcp3208

def update_spi_adc_speed(ev):
    global global_spi_speed_adc
    global_spi_speed_adc = int(adc_spi_speed_var.get().split("/")[0])
    print("new adc spi speed: "+str(global_spi_speed_adc))

adc_spi_option_label = tk.Label(option_line, text="    ADC SPI Speed: ", font="Arial 10", anchor='w')
adc_spi_option_label.pack(side="left",fill="x")

adc_spi_option = tk.OptionMenu(option_line, adc_spi_speed_var, *adc_spi_speed_choices,
	command= update_spi_adc_speed)
adc_spi_option.config(width=20, font=('Helvetica', 10))
adc_spi_option.pack(side="left", fill="x")



fpga_spi_speed_var = tk.StringVar()
fpga_spi_speed_choices = [ 
	'20000000/20MHz',
	'15000000/15MHz',
	'10000000/10MHz',
	'1000000/100KHz',
	'100000/100KHz' 
#	'10000/10KHz',
#	'1000/1KHz',
#	'100/100Hz' 
]

#fpga_spi_speed_var.set('25000000/25MHz') # set the default option
#global_spi_speed_fpga= 25000000 # max speed 
fpga_spi_speed_var.set('10000000/10MHz') # set the default option
global_spi_speed_fpga= 10000000 # second max speed 

def update_spi_fpga_speed(ev):
    global global_spi_speed_fpga
    global_spi_speed_fpga = int(fpga_spi_speed_var.get().split("/")[0])
    print("new fpga spi speed: "+str(global_spi_speed_fpga))

fpga_spi_option_label = tk.Label(option_line, text="    FPGA SPI Speed: ", font="Arial 10", anchor='w')
fpga_spi_option_label.pack(side="left",fill="x")

fpga_spi_option = tk.OptionMenu(option_line, fpga_spi_speed_var, *fpga_spi_speed_choices,
	command= update_spi_fpga_speed)
fpga_spi_option.config(width=20, font=('Helvetica', 10))
fpga_spi_option.pack(side="left", fill="x")




#### STATUS LINE AREA ####

countbox= tk.StringVar()
counts = tk.Entry(status_line, textvariable=countbox, width=40).pack(side=tk.LEFT)
countbox.set("Samples#: ")

timebox= tk.StringVar()
times = tk.Entry(status_line, textvariable=timebox, width=20).pack(side=tk.LEFT)
timebox.set("Duration: ")

speedbox= tk.StringVar()
speeds = tk.Entry(status_line, textvariable=speedbox, width=20).pack(side=tk.LEFT)
speedbox.set("Speed: ")

fftbox= tk.StringVar()
ffts = tk.Entry(status_line, textvariable=fftbox, width=20).pack(side=tk.LEFT)
fftbox.set("FFT total block#: ")

replayfftbox= tk.StringVar()
replayffts = tk.Entry(status_line, textvariable=replayfftbox, width=20).pack(side=tk.LEFT)
replayfftbox.set("FFT replay block#: ")



#### BUTTON LINE AREA ####

tk.Button(button_line,text="Real Capture",command=capture_start_real).pack(side=tk.LEFT)
tk.Button(button_line,text="Fake Capture",command=capture_start_fake).pack(side=tk.LEFT)
tk.Button(button_line,text="Capture Stop",command=capture_stop).pack(side=tk.LEFT)
tk.Button(button_line,text="Process FFT",command=fft_process).pack(side=tk.LEFT)
tk.Button(button_line,text="Replay FFT",command=fft_replay).pack(side=tk.LEFT)
tk.Button(button_line,text=" E x i t ",command=exit1).pack(side=tk.LEFT)



#### GRAPH X,Y CONSTANTS SETUP ####

#block_size=1024
#block_size=512
block_size=256
half_block_size= int(block_size/2)

# fpga 로부터의 fft result 는,  256의입력의 경우 7을 더한 263 개의 결과값이 리턴된다
block_size_fft_result= block_size + 7 

#acq_max_frequency=22050
#rpi3 에서는 python 구현시 최대 대이타 취득 샘플링 속도가 초당 14000을 넘기 힘들다
#rip4 에서는 22000 정도는 가능할 수도 이다
acq_max_frequency=14000


## 실제 adc 취득 후에 샘플링 속도가 결정되며, 아래의 잠정치를 대체하게 된다
freq_unit= acq_max_frequency
fmax_pos=  freq_unit
fmax_neg=  -freq_unit
# ax2 그래프의 x 축 정의역 (샘플링 전까지 임시 용도)
#freq_xrange= np.linspace(fmax_neg, fmax_pos, block_size)
freq_xrange= np.linspace(0, fmax_pos, half_block_size)


# 1초당 취득 가능한 최대 데이터 블록 숫자 
block_per_sec= int(acq_max_frequency / block_size)

# 최대 지원 가능한 샘플링 기간을 초단위로 지정한다
max_capture_duration_sec=4

# 최대 지원 가능한 샘플 블록 숫자를 지정한다
num_view_samples_block= max_capture_duration_sec * block_per_sec

# 최대 지원 가능한 샘플 숫자를 지정한다
num_view_samples= num_view_samples_block * block_size

### adc 로부터 취득한 1024 비트 신호값의 상위바이트,하위바이트 배열 (0 초기화)
fpga_input=  numpy.zeros([num_view_samples_block, block_size, 2], dtype=int)

## 263 elements fpga output
fpga_output_raw= numpy.zeros([num_view_samples_block, block_size_fft_result, 8], dtype=int)

## sqrt(x*x+y*y) 된 amplitude 값 ( 0 초기화 )
fpga_output_amp= numpy.zeros([num_view_samples_block, block_size], dtype=int)


## 10bit signal amplitude for ax1
signal_max1= 1024
sample_signal_min=0
sample_signal_max=signal_max1

## max fft amplitude for ax2
#signal_max2= 20000
signal_max2= 1200

## ax1 그래프에서 한번에 보여줄 샘플의 수 (그래프 x 축 뷰포트)
#one_view_samples=4096
one_view_samples=2048
one_view_samples_half= int(one_view_samples/2)




#### TWO GRAPHS  X,Y RANGE SETUP ####

## 상단 그래프
ax1 = fig.add_subplot(211, xlim=(0, num_view_samples), ylim=(0,signal_max1))
ax1_color='blue'

## 하단 그래프
#ax2 = fig.add_subplot(212, xlim=(fmax_neg, fmax_pos), ylim=(0, signal_max2))
#ax2 = fig.add_subplot(212, xlim=(fmax_neg, fmax_pos), ylim=(-signal_max2, signal_max2))
ax2 = fig.add_subplot(212, xlim=(0, fmax_pos), ylim=(0, signal_max2))
ax2_bar_color='red'
ax2_bar_width=1.0
ax2_bar_linewidth=2

## 각 그래프의 상하좌우 여백을 정의
plt.subplots_adjust(left=0.1,right=0.9,top=0.90,bottom=0.1)

# ax1 그래프:  (nan 을 초기 y 값으로 하며, 초기 그래프에 실선이 그어지지 않는다)
line1, = ax1.plot(np.arange(num_view_samples),np.ones(num_view_samples, dtype=np.float)*np.nan, lw=1, c=ax1_color,ms=1)

# ax2 그래프: 
line2, = ax2.plot(freq_xrange,np.ones(len(freq_xrange), dtype=np.float)*np.nan, lw=1, c=ax2_bar_color,ms=1)


#### TWO GRAPHS  TITLE/AXIS 설정

ax1.set_ylabel('Pulse Amplitude (0~'+str(signal_max1)+')')
ax1.set_xlabel('Samples #')
ax1.set_title('Raw PCM Source: No captured sound data yet')
ax1.xaxis.set_label_coords(1.05, -0.025)
ax1.axis([0,one_view_samples,0,signal_max1])

#ax2.set_xlabel('Frequency (-10 KHz ~ 10 KHz)')
#ax2.set_ylabel('Freq Amplitude (-20k ~ 20k)')
ax2.set_xlabel('Frequency (0 KHz ~ 10 KHz)')
ax2.set_ylabel('Freq Amplitude (0 ~ '+str(signal_max2)+')')
ax2.set_title('Frequency Distribution from FFT for highlighted '+str(block_size)+' samples block above',pad=-90)


# Eliminate upper and right axes of ax2
ax2.spines['right'].set_color('none')
ax2.spines['top'].set_color('none')

# Show ticks in the left and lower axes only for ax2
ax2.xaxis.set_ticks_position('bottom')
ax2.yaxis.set_ticks_position('left')


## plot y_data arrays for ax1,ax2
line_data1 = line1.get_ydata()
line_data2 = line2.get_ydata()
init_line_data1 = np.array(line_data1, dtype=float)
init_line_data2 = np.array(line_data2, dtype=float)


### 최상단 샘플 데이타 선택 슬라이더(프로그레스바의 역할도 한다)

axpos = plt.axes([0.1, 0.95, 0.8, 0.02])
spos = Slider(ax=axpos, label='Samples:', valmin=0, valmax=num_view_samples, valfmt="%d", valinit=one_view_samples)
spos.on_changed(update_ax1_onclick)


###
debug_log= False
#debug_log=True

### RUN MAIN ###
def main():
  rpi_gpio_setup()
  tk_clock()
  root.mainloop()

main()
