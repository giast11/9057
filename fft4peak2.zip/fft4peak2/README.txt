
1. 설치 

   $ cd ~
   $ tar xvf fft4.tar      혹은    $ unzip fft4.zip
   $ cd fft4

2. 실행 : x-window terminal 에서 실행 

   $ ./fft4.py  ## fft 가 pos,neg 모두 포함하여 보여줌
   $ ./fft4pos.py  ## fft 가 pos만  포함하여 보여줌

2. 실행 : window mobaxterm terminal 에서 실행 

   C> ssh pi@192.168.1.X
   $ sudo bash
   #vi /etc/ssh/ssh_config
  
    #ForwardX11 = no
    를  코멘트 표시 # 를 제하고 
    ForwardX11 = yes
    로 바꾸어 저장해 주어야 한다

   #exit
   $exit

   ssh 연결 해제하고 -Y 옵션붙여 다시 ssh 연결한다
   -Y 옵션을 붙이면 mobaxterm 으로 rpi 의 x-windows 어풀을 띄울 수 있다

   C> ssh -Y pi@192.168.1.X

   $ cd fft4
   $ ./fft4.py

   윈도우상에서 x-window tk 윈도욱가 뜬다


3. 사전 설치 준비: 오래된 버전의 matplotlib 를 먼저 시스템에서 제거
 
 # sudo apt remove python3-matplotlib
 # sudo apt remove python3-tk
 # sudo pip3 uninstall matplotlib

 아직 설치되어 있지 않다면 에러가 날수도 있으나 무시.


4. 사전 설치 준비: 사전 인스톨 필요한 Python3 패키지
   새버전의 matplotlib, tkinter Tk 툴킷, mttkinter  파이선 라이브러리를 설치해야 함

 # sudo apt update 
 # sudo apt install python3-tk

 # sudo pip3 install matplotlib
 # sudo pip3 install mttkinter 
 # sudo pip3 install numpy
 # sudo pip3 install RPi.GPIO



5. adc 취득시 gui 와의 cpu / IO  자원 경쟁 문제

   adc 취득시 gui 프로그램이 화면을 업데이트하면
   샘플링속도가 크게 줄어드는 현상 (rpi3)

   spi 로 데이타룰 주고 받을 때는 GUI 동작을 하지 
   않도록 조치함

   GUI 와 ADC 취득을 실시간으로 처리할면 
   rpi3 업시, zynq 개발보드에 바로 꽂아 쓰는 전용 ADC
   사용 권장


6. mcc3208 spi clock 문제

 mcp3208: 2Mhz SPI clock 이 최대속도,  zynq 7020 api 는 25Mhz SPI clock 최대
 이 둘을 같은 spi device 에 두개의 slave 로 물리려면 2Mhz (둘중 작은 속도에 맞추어) 로 설정해야
 하는데, 2Mhz 도 최대치일뿐, mcp3208 이 안정적 동작하려면, 1Mhz 로 낮추는게 필요 
 1Mhz 이면  8Khz 샘플링도 겨우 해내는 수준임 -> FPGA 와 같은 고속 spi device 를 추가로 물릴 수 없음.
 FPGA 만 따로 떼서 rpi spi 에 25Mhz 로  설정해도, 22Khz 지원에는 40Mbps 이상이 필요해  
 따라서 역산해보면, FPGA 역시   8Khz 샘플링이  최대임
 결론: adc와 fpga 를 한개의 spi device 에 두개의 slave device 로 설정하는 것은 rpi 에서 불가
 각각 별개의 rpi (2개 마련) 할당해서 이더넷으로 물려도, 최대 8Khz 음성 샘플링이 최대치임.

 rpi3 에서 2Mhz 로 spi bus 를 설정하고 adc 에서 읽으면 13000 khz (sps) 정도의 속도가 나오고 있음


7. mcp3208 3.3v 공급 

  mcp3208 은 3.3v 로 작동하며, analog mic (robodyn, 국내 device마트등에서 흔히 파는) 는 
  보통 5v 로 작동하므로 rpi 핀들에서 서로 다른 voltage 선을 인입하여 각각 따로 연결해야 했음
  GND 는 공유가 가능함 

  아나로그 마이크에 있는 포텐셔미터 저항값을 십자드라이버로 조정해서 출력 아나로그 전압값을
  다운시킬 수 있음


8. FPGA Dout 을 on/off 하기위한 relay module 연결

  5v 2 switch relay module 을 rpi gpio 18,21 번에 연결하여, FPGA Dout 을 ADC 취득 시에 방해되지
  않도록 relay1_on() relay1_off() 등의 함수를 추가혀였다.

  relay1_on() 은 FPGA Dout 을 RPI 의 MISO 에 연결케 하며 
  relay1_off() 은 FPGA Dout 을 RPI 의 MISO 와 연결을 끊는다 (ADC 의 Dout 과 회선 결쟁을 하지 않게 함)



9. LINE/PULSE 모드 Selection

  Choose between Line / Pulse (default) style graph fo FFT Result


10. relay1,relay2 모두 함께 on/off

  FPGA 의 MISO 를 relay1,relay2 어디에 연결해도 on/off 되게 고침 


11. fft 결과 중앙 피크값 교정

  fft 결과 값(263개)중  127,129 번째값을 무조건 0 으로 교청


12. adc 읽기 속도 선택

  상태 라인위에 ADC SPI 속도를 선택할 수 있는 메뉴를 둠  

  아래 adc spi 속도별 sps 수치는 개발자의 rpi3 에서 실험한 결과이며,
    다른 rpi  에서는 속도가 약간 다르게 나올 수 있다 

  fft4.py 에 아래 선언줄을 검색해서 수정할 수 있다 
 
  adc_spi_speed_choices = [
        '2000000/2MHz/24,000sps',
        '1000000/1MHz/17,800sps',
        '500000/500KHz/7,100sps',
        '250000/250KHz/3,600sps',
        '125000/125KHz/2,100sps',
        '62500/62.5KHz/1,200sps',
        '31300/31.3KHz/650sps',
        '15200/15.2KHz/330sps'
  ]

  adc_spi_speed_var.set('2000000/2MHz/24,000sps') # set the default option
  global_spi_speed_adc= 2000000 # 2MHz max
 
  위 선택 박스 옵션값의 맨앞의 숫자를 spi 속도이며, 다음만 spi_open_adc() 호출에서 사용된다.


13. fpga spi speed adjust

  fpga_spi_speed_choices = [
        '25000000/25MHz',
        '10000000/10MHz',
        '1000000/1MHz',
        '100000/100KHz',
        '10000/10KHz',
        '1000/1KHz',
        '100/100Hz'
  ]

  fpga_spi_speed_var.set('25000000/25MHz') # set the default option
  global_spi_speed_fpga= 25000000 

  used by spi_open_fpga()
